package net.mcreator.stratospherion.network;

import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.chat.Component;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.core.SectionPos;

import net.mcreator.stratospherion.procedures.*;
import net.mcreator.stratospherion.StratospherionMod;

@EventBusSubscriber
public record EveDialogueMenuButtonMessage(int buttonID, int x, int y, int z) implements CustomPacketPayload {
	public static final Type<EveDialogueMenuButtonMessage> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(StratospherionMod.MODID, "eve_dialogue_menu_buttons"));
	public static final StreamCodec<RegistryFriendlyByteBuf, EveDialogueMenuButtonMessage> STREAM_CODEC = StreamCodec.of((RegistryFriendlyByteBuf buffer, EveDialogueMenuButtonMessage message) -> {
		buffer.writeInt(message.buttonID);
		buffer.writeInt(message.x);
		buffer.writeInt(message.y);
		buffer.writeInt(message.z);
	}, (RegistryFriendlyByteBuf buffer) -> new EveDialogueMenuButtonMessage(buffer.readInt(), buffer.readInt(), buffer.readInt(), buffer.readInt()));

	@Override
	public Type<EveDialogueMenuButtonMessage> type() {
		return TYPE;
	}

	public static void handleData(final EveDialogueMenuButtonMessage message, final IPayloadContext context) {
		if (context.flow() == PacketFlow.SERVERBOUND) {
			context.enqueueWork(() -> handleButtonAction(context.player(), message.buttonID, message.x, message.y, message.z)).exceptionally(e -> {
				context.connection().disconnect(Component.literal(e.getMessage()));
				return null;
			});
		}
	}

	public static void handleButtonAction(Player entity, int buttonID, int x, int y, int z) {
		Level world = entity.level();
		// security measure to prevent arbitrary chunk generation
		if (!world.getChunkSource().hasChunk(SectionPos.blockToSectionCoord(x), SectionPos.blockToSectionCoord(z)))
			return;
		if (buttonID == 0) {

			OnButtonClickedDayProcedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 1) {

			OnButtonClickedStatusProcedure.execute(world, x, y, z);
		}
		if (buttonID == 2) {

			OnButtonClickedMissionProcedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 3) {

			OnButtonClickedNightProcedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 4) {

			OnButtonClickedNoonProcedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 5) {

			OnButtonClickedEchoProcedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 6) {

			OnButtonClickedSentryProcedure.execute(world, x, y, z, entity);
		}
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		StratospherionMod.addNetworkMessage(EveDialogueMenuButtonMessage.TYPE, EveDialogueMenuButtonMessage.STREAM_CODEC, EveDialogueMenuButtonMessage::handleData);
	}
}