package net.mcreator.stratospherion.entity;

import net.neoforged.neoforge.fluids.FluidType;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.EventHooks;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.Slime;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.*;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.util.RandomSource;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

import net.mcreator.stratospherion.procedures.EveThisEntityKillsAnotherOneProcedure;
import net.mcreator.stratospherion.procedures.EveRightclickedOnEntityGUIProcedure;
import net.mcreator.stratospherion.procedures.EveOnInitialEntitySpawnProcedure;
import net.mcreator.stratospherion.procedures.EveOnDeathProcedure;
import net.mcreator.stratospherion.procedures.EveFlyConditionProcedure;
import net.mcreator.stratospherion.init.StratospherionModItems;
import net.mcreator.stratospherion.init.StratospherionModEntities;

import javax.annotation.Nullable;

import java.util.EnumSet;

public class EveEntity extends TamableAnimal implements RangedAttackMob {
	public final AnimationState animationState0 = new AnimationState();

	public EveEntity(EntityType<EveEntity> type, Level world) {
		super(type, world);
		xpReward = 0;
		setNoAi(false);
		setCustomName(Component.literal("Eve"));
		setCustomNameVisible(true);
		setPersistenceRequired();
		this.moveControl = new FlyingMoveControl(this, 10, true);
	}

	@Override
	protected PathNavigation createNavigation(Level world) {
		return new FlyingPathNavigation(this, world);
	}

	@Override
	protected void registerGoals() {
		super.registerGoals();
		this.goalSelector.addGoal(1, new FollowOwnerGoal(this, 1, (float) 10, (float) 2) {
			@Override
			public boolean canUse() {
				double x = EveEntity.this.getX();
				double y = EveEntity.this.getY();
				double z = EveEntity.this.getZ();
				Entity entity = EveEntity.this;
				Level world = EveEntity.this.level();
				return super.canUse() && EveFlyConditionProcedure.execute(entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = EveEntity.this.getX();
				double y = EveEntity.this.getY();
				double z = EveEntity.this.getZ();
				Entity entity = EveEntity.this;
				Level world = EveEntity.this.level();
				return super.canContinueToUse() && EveFlyConditionProcedure.execute(entity);
			}
		});
		this.targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
		this.goalSelector.addGoal(3, new OwnerHurtByTargetGoal(this));
		this.goalSelector.addGoal(4, new Goal() {
			{
				this.setFlags(EnumSet.of(Goal.Flag.MOVE));
			}

			public boolean canUse() {
				if (EveEntity.this.getTarget() != null && !EveEntity.this.getMoveControl().hasWanted()) {
					double x = EveEntity.this.getX();
					double y = EveEntity.this.getY();
					double z = EveEntity.this.getZ();
					Entity entity = EveEntity.this;
					Level world = EveEntity.this.level();
					return EveFlyConditionProcedure.execute(entity);
				} else {
					return false;
				}
			}

			@Override
			public boolean canContinueToUse() {
				double x = EveEntity.this.getX();
				double y = EveEntity.this.getY();
				double z = EveEntity.this.getZ();
				Entity entity = EveEntity.this;
				Level world = EveEntity.this.level();
				return EveFlyConditionProcedure.execute(entity) && EveEntity.this.getMoveControl().hasWanted() && EveEntity.this.getTarget() != null && EveEntity.this.getTarget().isAlive();
			}

			@Override
			public void start() {
				LivingEntity livingentity = EveEntity.this.getTarget();
				Vec3 vec3d = livingentity.getEyePosition(1);
				EveEntity.this.moveControl.setWantedPosition(vec3d.x, vec3d.y, vec3d.z, 1.6);
			}

			@Override
			public void tick() {
				LivingEntity livingentity = EveEntity.this.getTarget();
				if (EveEntity.this.getBoundingBox().intersects(livingentity.getBoundingBox())) {
					EveEntity.this.doHurtTarget(livingentity);
				} else {
					double d0 = EveEntity.this.distanceToSqr(livingentity);
					if (d0 < 20) {
						Vec3 vec3d = livingentity.getEyePosition(1);
						EveEntity.this.moveControl.setWantedPosition(vec3d.x, vec3d.y, vec3d.z, 1.6);
					}
				}
			}
		});
		this.targetSelector.addGoal(5, new HurtByTargetGoal(this) {
			@Override
			public boolean canUse() {
				double x = EveEntity.this.getX();
				double y = EveEntity.this.getY();
				double z = EveEntity.this.getZ();
				Entity entity = EveEntity.this;
				Level world = EveEntity.this.level();
				return super.canUse() && EveFlyConditionProcedure.execute(entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = EveEntity.this.getX();
				double y = EveEntity.this.getY();
				double z = EveEntity.this.getZ();
				Entity entity = EveEntity.this;
				Level world = EveEntity.this.level();
				return super.canContinueToUse() && EveFlyConditionProcedure.execute(entity);
			}
		}.setAlertOthers());
		this.targetSelector.addGoal(6, new NearestAttackableTargetGoal(this, Monster.class, true, false) {
			@Override
			public boolean canUse() {
				double x = EveEntity.this.getX();
				double y = EveEntity.this.getY();
				double z = EveEntity.this.getZ();
				Entity entity = EveEntity.this;
				Level world = EveEntity.this.level();
				return super.canUse() && EveFlyConditionProcedure.execute(entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = EveEntity.this.getX();
				double y = EveEntity.this.getY();
				double z = EveEntity.this.getZ();
				Entity entity = EveEntity.this;
				Level world = EveEntity.this.level();
				return super.canContinueToUse() && EveFlyConditionProcedure.execute(entity);
			}
		});
		this.targetSelector.addGoal(7, new NearestAttackableTargetGoal(this, Slime.class, true, false) {
			@Override
			public boolean canUse() {
				double x = EveEntity.this.getX();
				double y = EveEntity.this.getY();
				double z = EveEntity.this.getZ();
				Entity entity = EveEntity.this;
				Level world = EveEntity.this.level();
				return super.canUse() && EveFlyConditionProcedure.execute(entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = EveEntity.this.getX();
				double y = EveEntity.this.getY();
				double z = EveEntity.this.getZ();
				Entity entity = EveEntity.this;
				Level world = EveEntity.this.level();
				return super.canContinueToUse() && EveFlyConditionProcedure.execute(entity);
			}
		});
		this.goalSelector.addGoal(8, new RandomStrollGoal(this, 0.3, 20) {
			@Override
			protected Vec3 getPosition() {
				RandomSource random = EveEntity.this.getRandom();
				double dir_x = EveEntity.this.getX() + ((random.nextFloat() * 2 - 1) * 16);
				double dir_y = EveEntity.this.getY() + ((random.nextFloat() * 2 - 1) * 16);
				double dir_z = EveEntity.this.getZ() + ((random.nextFloat() * 2 - 1) * 16);
				return new Vec3(dir_x, dir_y, dir_z);
			}

			@Override
			public boolean canUse() {
				double x = EveEntity.this.getX();
				double y = EveEntity.this.getY();
				double z = EveEntity.this.getZ();
				Entity entity = EveEntity.this;
				Level world = EveEntity.this.level();
				return super.canUse() && EveFlyConditionProcedure.execute(entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = EveEntity.this.getX();
				double y = EveEntity.this.getY();
				double z = EveEntity.this.getZ();
				Entity entity = EveEntity.this;
				Level world = EveEntity.this.level();
				return super.canContinueToUse() && EveFlyConditionProcedure.execute(entity);
			}

		});
		this.goalSelector.addGoal(9, new TemptGoal(this, 1, Ingredient.of(StratospherionModItems.NANOTECH.get()), false));
		this.goalSelector.addGoal(10, new RandomLookAroundGoal(this) {
			@Override
			public boolean canUse() {
				double x = EveEntity.this.getX();
				double y = EveEntity.this.getY();
				double z = EveEntity.this.getZ();
				Entity entity = EveEntity.this;
				Level world = EveEntity.this.level();
				return super.canUse() && EveFlyConditionProcedure.execute(entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = EveEntity.this.getX();
				double y = EveEntity.this.getY();
				double z = EveEntity.this.getZ();
				Entity entity = EveEntity.this;
				Level world = EveEntity.this.level();
				return super.canContinueToUse() && EveFlyConditionProcedure.execute(entity);
			}
		});
		this.goalSelector.addGoal(11, new FloatGoal(this) {
			@Override
			public boolean canUse() {
				double x = EveEntity.this.getX();
				double y = EveEntity.this.getY();
				double z = EveEntity.this.getZ();
				Entity entity = EveEntity.this;
				Level world = EveEntity.this.level();
				return super.canUse() && EveFlyConditionProcedure.execute(entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = EveEntity.this.getX();
				double y = EveEntity.this.getY();
				double z = EveEntity.this.getZ();
				Entity entity = EveEntity.this;
				Level world = EveEntity.this.level();
				return super.canContinueToUse() && EveFlyConditionProcedure.execute(entity);
			}
		});
		this.goalSelector.addGoal(1, new RangedAttackGoal(this, 1.25, 30, 30f) {
			@Override
			public boolean canContinueToUse() {
				return this.canUse();
			}
		});
	}

	@Override
	public boolean removeWhenFarAway(double distanceToClosestPlayer) {
		return false;
	}

	@Override
	public SoundEvent getAmbientSound() {
		return BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:eve_ambient"));
	}

	@Override
	public SoundEvent getHurtSound(DamageSource ds) {
		return BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:eve_hurt"));
	}

	@Override
	public SoundEvent getDeathSound() {
		return BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:eve_death"));
	}

	@Override
	public boolean causeFallDamage(float l, float d, DamageSource source) {
		return false;
	}

	@Override
	public boolean hurt(DamageSource damagesource, float amount) {
		if (damagesource.is(DamageTypes.FALL))
			return false;
		if (damagesource.is(DamageTypes.CACTUS))
			return false;
		if (damagesource.is(DamageTypes.DROWN))
			return false;
		return super.hurt(damagesource, amount);
	}

	@Override
	public void die(DamageSource source) {
		super.die(source);
		EveOnDeathProcedure.execute(this.level(), this.getX(), this.getY(), this.getZ(), this);
	}

	@Override
	public SpawnGroupData finalizeSpawn(ServerLevelAccessor world, DifficultyInstance difficulty, MobSpawnType reason, @Nullable SpawnGroupData livingdata) {
		SpawnGroupData retval = super.finalizeSpawn(world, difficulty, reason, livingdata);
		EveOnInitialEntitySpawnProcedure.execute(world, this.getX(), this.getY(), this.getZ(), this);
		return retval;
	}

	@Override
	public InteractionResult mobInteract(Player sourceentity, InteractionHand hand) {
		ItemStack itemstack = sourceentity.getItemInHand(hand);
		InteractionResult retval = InteractionResult.sidedSuccess(this.level().isClientSide());
		Item item = itemstack.getItem();
		if (itemstack.getItem() instanceof SpawnEggItem) {
			retval = super.mobInteract(sourceentity, hand);
		} else if (this.level().isClientSide()) {
			retval = (this.isTame() && this.isOwnedBy(sourceentity) || this.isFood(itemstack)) ? InteractionResult.sidedSuccess(this.level().isClientSide()) : InteractionResult.PASS;
		} else {
			if (this.isTame()) {
				if (this.isOwnedBy(sourceentity)) {
					if (this.isFood(itemstack) && this.getHealth() < this.getMaxHealth()) {
						this.usePlayerItem(sourceentity, hand, itemstack);
						FoodProperties foodproperties = itemstack.getFoodProperties(this);
						float nutrition = foodproperties != null ? (float) foodproperties.nutrition() : 1;
						this.heal(nutrition);
						retval = InteractionResult.sidedSuccess(this.level().isClientSide());
					} else if (this.isFood(itemstack) && this.getHealth() < this.getMaxHealth()) {
						this.usePlayerItem(sourceentity, hand, itemstack);
						this.heal(4);
						retval = InteractionResult.sidedSuccess(this.level().isClientSide());
					} else {
						retval = super.mobInteract(sourceentity, hand);
					}
				}
			} else if (this.isFood(itemstack)) {
				this.usePlayerItem(sourceentity, hand, itemstack);
				if (this.random.nextInt(3) == 0 && !EventHooks.onAnimalTame(this, sourceentity)) {
					this.tame(sourceentity);
					this.level().broadcastEntityEvent(this, (byte) 7);
				} else {
					this.level().broadcastEntityEvent(this, (byte) 6);
				}
				this.setPersistenceRequired();
				retval = InteractionResult.sidedSuccess(this.level().isClientSide());
			} else {
				retval = super.mobInteract(sourceentity, hand);
				if (retval == InteractionResult.SUCCESS || retval == InteractionResult.CONSUME)
					this.setPersistenceRequired();
			}
		}
		double x = this.getX();
		double y = this.getY();
		double z = this.getZ();
		Entity entity = this;
		Level world = this.level();

		EveRightclickedOnEntityGUIProcedure.execute(world, x, y, z, entity, sourceentity);
		return retval;
	}

	@Override
	public void awardKillScore(Entity entity, int score, DamageSource damageSource) {
		super.awardKillScore(entity, score, damageSource);
		EveThisEntityKillsAnotherOneProcedure.execute(this);
	}

	@Override
	public void tick() {
		super.tick();
		if (this.level().isClientSide()) {
			this.animationState0.animateWhen(true, this.tickCount);
		}
	}

	@Override
	public void performRangedAttack(LivingEntity target, float flval) {
		BeamEntity.shoot(this, target);
	}

	@Override
	public AgeableMob getBreedOffspring(ServerLevel serverWorld, AgeableMob ageable) {
		EveEntity retval = StratospherionModEntities.EVE.get().create(serverWorld);
		retval.finalizeSpawn(serverWorld, serverWorld.getCurrentDifficultyAt(retval.blockPosition()), MobSpawnType.BREEDING, null);
		return retval;
	}

	@Override
	public boolean isFood(ItemStack stack) {
		return Ingredient.of(new ItemStack(StratospherionModItems.NANOTECH.get())).test(stack);
	}

	@Override
	public boolean canDrownInFluidType(FluidType type) {
		double x = this.getX();
		double y = this.getY();
		double z = this.getZ();
		Level world = this.level();
		Entity entity = this;
		return false;
	}

	@Override
	protected void checkFallDamage(double y, boolean onGroundIn, BlockState state, BlockPos pos) {
	}

	@Override
	public void setNoGravity(boolean ignored) {
		super.setNoGravity(true);
	}

	@Override
	public void aiStep() {
		super.aiStep();
		this.setNoGravity(true);
	}

	@Override
	protected float getFlyingSpeed() {
		return (float) this.getAttributeValue(Attributes.FLYING_SPEED);
	}

	public static void init(RegisterSpawnPlacementsEvent event) {
	}

	public static AttributeSupplier.Builder createAttributes() {
		AttributeSupplier.Builder builder = Mob.createMobAttributes();
		builder = builder.add(Attributes.MOVEMENT_SPEED, 0.2);
		builder = builder.add(Attributes.MAX_HEALTH, 40);
		builder = builder.add(Attributes.ARMOR, 5);
		builder = builder.add(Attributes.ATTACK_DAMAGE, 1);
		builder = builder.add(Attributes.FOLLOW_RANGE, 20);
		builder = builder.add(Attributes.STEP_HEIGHT, 0.6);
		builder = builder.add(Attributes.FLYING_SPEED, 0.2);
		return builder;
	}
}