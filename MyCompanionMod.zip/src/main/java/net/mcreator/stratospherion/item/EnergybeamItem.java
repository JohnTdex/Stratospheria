package net.mcreator.stratospherion.item;

import net.minecraft.world.item.Item;

public class EnergybeamItem extends Item {
	public EnergybeamItem() {
		super(new Item.Properties());
	}
}