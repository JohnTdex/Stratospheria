package net.mcreator.stratospherion.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class NanotechItem extends Item {
	public NanotechItem() {
		super(new Item.Properties().rarity(Rarity.UNCOMMON));
	}
}