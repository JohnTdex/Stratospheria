package net.mcreator.stratospherion.client.model;

import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

// Made with Blockbench 5.1.4
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports
public class Modeleve<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath("stratospherion", "modeleve"), "main");
	public final ModelPart eve;
	public final ModelPart body;
	public final ModelPart plating;
	public final ModelPart eyes;
	public final ModelPart thrusters;
	public final ModelPart wing;
	public final ModelPart propeller;
	public final ModelPart propeller_2;

	public Modeleve(ModelPart root) {
		this.eve = root.getChild("eve");
		this.body = this.eve.getChild("body");
		this.plating = this.eve.getChild("plating");
		this.eyes = this.eve.getChild("eyes");
		this.thrusters = this.eve.getChild("thrusters");
		this.wing = this.eve.getChild("wing");
		this.propeller = this.eve.getChild("propeller");
		this.propeller_2 = this.eve.getChild("propeller_2");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition eve = partdefinition.addOrReplaceChild("eve", CubeListBuilder.create(), PartPose.offset(0.0F, 14.0F, 0.0F));
		PartDefinition body = eve.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, -2.0F, -3.0F, 6.0F, 4.0F, 6.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 0.0F, 0.0F));
		PartDefinition plating = eve.addOrReplaceChild("plating",
				CubeListBuilder.create().texOffs(28, 14).addBox(-3.0F, -3.0F, -2.8333F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(28, 16).addBox(-3.0F, 2.0F, -2.8333F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(20, 31)
						.addBox(-4.0F, -2.0F, -2.8333F, 1.0F, 4.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(24, 31).addBox(3.0F, -2.0F, -2.8333F, 1.0F, 4.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(14, 10)
						.addBox(-4.0F, -3.0F, -1.8333F, 1.0F, 1.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(0, 17).addBox(3.0F, -3.0F, -1.8333F, 1.0F, 1.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(0, 24)
						.addBox(1.0F, -3.0F, -1.8333F, 1.0F, 1.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(24, 0).addBox(-2.0F, -3.0F, -1.8333F, 1.0F, 1.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(0, 10)
						.addBox(-4.0F, 2.0F, -1.8333F, 1.0F, 1.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(14, 24).addBox(-2.0F, 2.0F, -1.8333F, 1.0F, 1.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(28, 7)
						.addBox(1.0F, 2.0F, -1.8333F, 1.0F, 1.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(14, 17).addBox(3.0F, 2.0F, -1.8333F, 1.0F, 1.0F, 6.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 0.0F, -1.1667F));
		PartDefinition eyes = eve.addOrReplaceChild("eyes",
				CubeListBuilder.create().texOffs(8, 31).addBox(0.5F, -1.0F, -0.5F, 2.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(14, 31).addBox(-2.5F, -1.0F, -0.5F, 2.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 0.0F, -3.5F));
		PartDefinition thrusters = eve.addOrReplaceChild("thrusters",
				CubeListBuilder.create().texOffs(28, 18).addBox(1.0F, -12.0F, 3.0F, 2.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(28, 24).addBox(-3.0F, -12.0F, 3.0F, 2.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(29, 25)
						.addBox(-3.0F, -10.0F, 3.0F, 2.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(29, 19).addBox(1.0F, -10.0F, 3.0F, 2.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 10.0F, 0.0F));
		PartDefinition wing = eve.addOrReplaceChild("wing",
				CubeListBuilder.create().texOffs(37, 33).addBox(-7.0F, -10.0F, 2.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(37, 31).addBox(-7.0F, -10.0F, -3.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(43, 31)
						.addBox(-8.0F, -10.0F, -2.0F, 1.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(37, 31).addBox(3.0F, -10.0F, -3.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(37, 33)
						.addBox(3.0F, -10.0F, 2.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 10.0F, 0.0F));
		PartDefinition left_r1 = wing.addOrReplaceChild("left_r1", CubeListBuilder.create().texOffs(43, 31).addBox(-0.5F, -0.5F, -2.0F, 1.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(7.5F, -9.5F, 0.0F, 0.0F, 0.0F, -3.1416F));
		PartDefinition propeller = eve.addOrReplaceChild("propeller", CubeListBuilder.create().texOffs(35, 38).addBox(-1.0F, -0.5F, -1.0F, 2.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(-5.0F, 0.5F, 0.0F));
		PartDefinition propeller_2 = eve.addOrReplaceChild("propeller_2", CubeListBuilder.create().texOffs(35, 38).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(5.0F, 1.0F, 0.0F));
		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, int rgb) {
		eve.render(poseStack, vertexConsumer, packedLight, packedOverlay, rgb);
	}

	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}
}