package net.mcreator.stratospherion.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.Minecraft;

import net.mcreator.stratospherion.entity.EveEntity;
import net.mcreator.stratospherion.client.model.animations.eveAnimation;
import net.mcreator.stratospherion.client.model.Modeleve;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class EveRenderer extends MobRenderer<EveEntity, Modeleve<EveEntity>> {
	private final ResourceLocation entityTexture = ResourceLocation.parse("stratospherion:textures/entities/eve.png");

	public EveRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(Modeleve.LAYER_LOCATION)), 0.5f);
		this.addLayer(new RenderLayer<EveEntity, Modeleve<EveEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = ResourceLocation.parse("stratospherion:textures/entities/eve.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, EveEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
				EntityModel model = new Modeleve(Minecraft.getInstance().getEntityModels().bakeLayer(Modeleve.LAYER_LOCATION));
				this.getParentModel().copyPropertiesTo(model);
				model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
				model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
				model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0));
			}
		});
		this.addLayer(new RenderLayer<EveEntity, Modeleve<EveEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = ResourceLocation.parse("stratospherion:textures/entities/eve_glow.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, EveEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.eyes(LAYER_TEXTURE));
				EntityModel model = new Modeleve(Minecraft.getInstance().getEntityModels().bakeLayer(Modeleve.LAYER_LOCATION));
				this.getParentModel().copyPropertiesTo(model);
				model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
				model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
				model.renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0));
			}
		});
	}

	@Override
	protected void scale(EveEntity entity, PoseStack poseStack, float f) {
		poseStack.scale(0.95f, 0.95f, 0.95f);
		poseStack.scale(entity.getAgeScale(), entity.getAgeScale(), entity.getAgeScale());
	}

	@Override
	public ResourceLocation getTextureLocation(EveEntity entity) {
		return entityTexture;
	}

	private static final class AnimatedModel extends Modeleve<EveEntity> {
		private final ModelPart root;
		private final HierarchicalModel animator = new HierarchicalModel<EveEntity>() {
			@Override
			public ModelPart root() {
				return root;
			}

			@Override
			public void setupAnim(EveEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
				this.root().getAllParts().forEach(ModelPart::resetPose);
				this.animate(entity.animationState0, eveAnimation.fly, ageInTicks, 5f);
			}
		};

		public AnimatedModel(ModelPart root) {
			super(root);
			this.root = root;
		}

		@Override
		public void setupAnim(EveEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
			animator.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
			super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
		}
	}
}