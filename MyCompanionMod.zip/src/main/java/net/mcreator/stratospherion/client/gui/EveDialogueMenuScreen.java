package net.mcreator.stratospherion.client.gui;

import net.neoforged.neoforge.network.PacketDistributor;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.stratospherion.world.inventory.EveDialogueMenuMenu;
import net.mcreator.stratospherion.network.EveDialogueMenuButtonMessage;
import net.mcreator.stratospherion.init.StratospherionModScreens;

import com.mojang.blaze3d.systems.RenderSystem;

public class EveDialogueMenuScreen extends AbstractContainerScreen<EveDialogueMenuMenu> implements StratospherionModScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	private Button button_good_morning;
	private Button button_whats_your_status;
	private Button button_eve_mission;
	private Button button_good_evening;
	private Button button_good_afternoon;
	private Button button_highlight_hostiles;
	private Button button_stay_mode;
	private static final ResourceLocation BACKGROUND = ResourceLocation.parse("stratospherion:textures/screens/eve_dialogue_menu.png");
	private static final ResourceLocation SPRITE_0 = ResourceLocation.parse("stratospherion:textures/screens/core.png");

	public EveDialogueMenuScreen(EveDialogueMenuMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 200;
		this.imageHeight = 166;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		menuStateUpdateActive = false;
	}

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int mouseX, int mouseY) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(BACKGROUND, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		guiGraphics.blit(SPRITE_0, this.leftPos + 8, this.topPos + 14, 0, 0, 16, 16, 16, 16);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.stratospherion.eve_dialogue_menu.label_hello_expeditioner"), 29, 19, -11231233, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.stratospherion.eve_dialogue_menu.label_terminal"), 77, 4, -11231233, false);
	}

	@Override
	public void init() {
		super.init();
		button_good_morning = Button.builder(Component.translatable("gui.stratospherion.eve_dialogue_menu.button_good_morning"), e -> {
			int x = EveDialogueMenuScreen.this.x;
			int y = EveDialogueMenuScreen.this.y;
			if (true) {
				PacketDistributor.sendToServer(new EveDialogueMenuButtonMessage(0, x, y, z));
				EveDialogueMenuButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).bounds(this.leftPos + 9, this.topPos + 37, 85, 20).build();
		this.addRenderableWidget(button_good_morning);
		button_whats_your_status = Button.builder(Component.translatable("gui.stratospherion.eve_dialogue_menu.button_whats_your_status"), e -> {
			int x = EveDialogueMenuScreen.this.x;
			int y = EveDialogueMenuScreen.this.y;
			if (true) {
				PacketDistributor.sendToServer(new EveDialogueMenuButtonMessage(1, x, y, z));
				EveDialogueMenuButtonMessage.handleButtonAction(entity, 1, x, y, z);
			}
		}).bounds(this.leftPos + 9, this.topPos + 87, 120, 20).build();
		this.addRenderableWidget(button_whats_your_status);
		button_eve_mission = Button.builder(Component.translatable("gui.stratospherion.eve_dialogue_menu.button_eve_mission"), e -> {
			int x = EveDialogueMenuScreen.this.x;
			int y = EveDialogueMenuScreen.this.y;
			if (true) {
				PacketDistributor.sendToServer(new EveDialogueMenuButtonMessage(2, x, y, z));
				EveDialogueMenuButtonMessage.handleButtonAction(entity, 2, x, y, z);
			}
		}).bounds(this.leftPos + 107, this.topPos + 60, 85, 20).build();
		this.addRenderableWidget(button_eve_mission);
		button_good_evening = Button.builder(Component.translatable("gui.stratospherion.eve_dialogue_menu.button_good_evening"), e -> {
			int x = EveDialogueMenuScreen.this.x;
			int y = EveDialogueMenuScreen.this.y;
			if (true) {
				PacketDistributor.sendToServer(new EveDialogueMenuButtonMessage(3, x, y, z));
				EveDialogueMenuButtonMessage.handleButtonAction(entity, 3, x, y, z);
			}
		}).bounds(this.leftPos + 107, this.topPos + 35, 85, 20).build();
		this.addRenderableWidget(button_good_evening);
		button_good_afternoon = Button.builder(Component.translatable("gui.stratospherion.eve_dialogue_menu.button_good_afternoon"), e -> {
			int x = EveDialogueMenuScreen.this.x;
			int y = EveDialogueMenuScreen.this.y;
			if (true) {
				PacketDistributor.sendToServer(new EveDialogueMenuButtonMessage(4, x, y, z));
				EveDialogueMenuButtonMessage.handleButtonAction(entity, 4, x, y, z);
			}
		}).bounds(this.leftPos + 9, this.topPos + 60, 95, 20).build();
		this.addRenderableWidget(button_good_afternoon);
		button_highlight_hostiles = Button.builder(Component.translatable("gui.stratospherion.eve_dialogue_menu.button_highlight_hostiles"), e -> {
			int x = EveDialogueMenuScreen.this.x;
			int y = EveDialogueMenuScreen.this.y;
			if (true) {
				PacketDistributor.sendToServer(new EveDialogueMenuButtonMessage(5, x, y, z));
				EveDialogueMenuButtonMessage.handleButtonAction(entity, 5, x, y, z);
			}
		}).bounds(this.leftPos + 9, this.topPos + 139, 115, 20).build();
		this.addRenderableWidget(button_highlight_hostiles);
		button_stay_mode = Button.builder(Component.translatable("gui.stratospherion.eve_dialogue_menu.button_stay_mode"), e -> {
			int x = EveDialogueMenuScreen.this.x;
			int y = EveDialogueMenuScreen.this.y;
			if (true) {
				PacketDistributor.sendToServer(new EveDialogueMenuButtonMessage(6, x, y, z));
				EveDialogueMenuButtonMessage.handleButtonAction(entity, 6, x, y, z);
			}
		}).bounds(this.leftPos + 9, this.topPos + 115, 70, 20).build();
		this.addRenderableWidget(button_stay_mode);
	}
}