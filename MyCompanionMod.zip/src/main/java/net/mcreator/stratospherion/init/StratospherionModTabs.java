/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stratospherion.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.stratospherion.StratospherionMod;

public class StratospherionModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, StratospherionMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> STRATOSPHERION = REGISTRY.register("stratospherion",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.stratospherion.stratospherion")).icon(() -> new ItemStack(StratospherionModItems.CORE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(StratospherionModItems.EVEACTIVATORDRONE.get());
				tabData.accept(StratospherionModItems.IRONSHELL.get());
				tabData.accept(StratospherionModItems.CORE.get());
				tabData.accept(StratospherionModItems.ENERGYBEAM.get());
				tabData.accept(StratospherionModItems.TIER_ONE_CORE.get());
				tabData.accept(StratospherionModItems.NANOTECH.get());
			}).build());
}