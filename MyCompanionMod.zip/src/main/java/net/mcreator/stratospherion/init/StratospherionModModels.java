/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stratospherion.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.stratospherion.client.model.Modeleverest;
import net.mcreator.stratospherion.client.model.Modeleve;
import net.mcreator.stratospherion.client.model.Modelbeam__entity;

@EventBusSubscriber(Dist.CLIENT)
public class StratospherionModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelbeam__entity.LAYER_LOCATION, Modelbeam__entity::createBodyLayer);
		event.registerLayerDefinition(Modeleve.LAYER_LOCATION, Modeleve::createBodyLayer);
		event.registerLayerDefinition(Modeleverest.LAYER_LOCATION, Modeleverest::createBodyLayer);
	}
}