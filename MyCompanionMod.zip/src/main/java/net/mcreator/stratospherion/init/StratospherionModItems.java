/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stratospherion.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;

import net.minecraft.world.item.Item;

import net.mcreator.stratospherion.item.*;
import net.mcreator.stratospherion.StratospherionMod;

public class StratospherionModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(StratospherionMod.MODID);
	public static final DeferredItem<Item> IRONSHELL;
	public static final DeferredItem<Item> CORE;
	public static final DeferredItem<Item> EVEACTIVATORDRONE;
	public static final DeferredItem<Item> ENERGYBEAM;
	public static final DeferredItem<Item> TIER_ONE_CORE;
	public static final DeferredItem<Item> NANOTECH;
	static {
		IRONSHELL = REGISTRY.register("ironshell", IronshellItem::new);
		CORE = REGISTRY.register("core", CoreItem::new);
		EVEACTIVATORDRONE = REGISTRY.register("eveactivatordrone", EveactivatordroneItem::new);
		ENERGYBEAM = REGISTRY.register("energybeam", EnergybeamItem::new);
		TIER_ONE_CORE = REGISTRY.register("tier_one_core", TierOneCoreItem::new);
		NANOTECH = REGISTRY.register("nanotech", NanotechItem::new);
	}
	// Start of user code block custom items
	// End of user code block custom items
}