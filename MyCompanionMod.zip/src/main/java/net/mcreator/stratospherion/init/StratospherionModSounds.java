/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stratospherion.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.mcreator.stratospherion.StratospherionMod;

public class StratospherionModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, StratospherionMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> EVE_AMBIENT = REGISTRY.register("eve_ambient", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stratospherion", "eve_ambient")));
	public static final DeferredHolder<SoundEvent, SoundEvent> EVE_HURT = REGISTRY.register("eve_hurt", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stratospherion", "eve_hurt")));
	public static final DeferredHolder<SoundEvent, SoundEvent> EVE_DEATH = REGISTRY.register("eve_death", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stratospherion", "eve_death")));
	public static final DeferredHolder<SoundEvent, SoundEvent> BEAM = REGISTRY.register("beam", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stratospherion", "beam")));
	public static final DeferredHolder<SoundEvent, SoundEvent> OHNORAIN = REGISTRY.register("ohnorain", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stratospherion", "ohnorain")));
	public static final DeferredHolder<SoundEvent, SoundEvent> GOODMORNING = REGISTRY.register("goodmorning", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stratospherion", "goodmorning")));
	public static final DeferredHolder<SoundEvent, SoundEvent> ANALYZING_COMPLETE = REGISTRY.register("analyzing_complete", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stratospherion", "analyzing_complete")));
	public static final DeferredHolder<SoundEvent, SoundEvent> FULL_HEALTH = REGISTRY.register("full_health", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stratospherion", "full_health")));
	public static final DeferredHolder<SoundEvent, SoundEvent> LOW_HEALTH = REGISTRY.register("low_health", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stratospherion", "low_health")));
	public static final DeferredHolder<SoundEvent, SoundEvent> ECHO = REGISTRY.register("echo", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stratospherion", "echo")));
	public static final DeferredHolder<SoundEvent, SoundEvent> MISSION = REGISTRY.register("mission", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stratospherion", "mission")));
	public static final DeferredHolder<SoundEvent, SoundEvent> SCAN = REGISTRY.register("scan", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stratospherion", "scan")));
	public static final DeferredHolder<SoundEvent, SoundEvent> DANGER = REGISTRY.register("danger", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stratospherion", "danger")));
	public static final DeferredHolder<SoundEvent, SoundEvent> SAFE = REGISTRY.register("safe", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stratospherion", "safe")));
	public static final DeferredHolder<SoundEvent, SoundEvent> EXPLOSION = REGISTRY.register("explosion", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stratospherion", "explosion")));
	public static final DeferredHolder<SoundEvent, SoundEvent> EVENING = REGISTRY.register("evening", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stratospherion", "evening")));
	public static final DeferredHolder<SoundEvent, SoundEvent> NIGHTRAIN = REGISTRY.register("nightrain", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stratospherion", "nightrain")));
	public static final DeferredHolder<SoundEvent, SoundEvent> MORNINGCORRECTION = REGISTRY.register("morningcorrection", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stratospherion", "morningcorrection")));
	public static final DeferredHolder<SoundEvent, SoundEvent> NOONCORRECTION = REGISTRY.register("nooncorrection", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stratospherion", "nooncorrection")));
	public static final DeferredHolder<SoundEvent, SoundEvent> NIGHTCORRECTION = REGISTRY.register("nightcorrection", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stratospherion", "nightcorrection")));
	public static final DeferredHolder<SoundEvent, SoundEvent> GOODAFTERNOON = REGISTRY.register("goodafternoon", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stratospherion", "goodafternoon")));
	public static final DeferredHolder<SoundEvent, SoundEvent> OFFLINE = REGISTRY.register("offline", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stratospherion", "offline")));
	public static final DeferredHolder<SoundEvent, SoundEvent> ONLINE = REGISTRY.register("online", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stratospherion", "online")));
	public static final DeferredHolder<SoundEvent, SoundEvent> NIGHTWARN = REGISTRY.register("nightwarn", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stratospherion", "nightwarn")));
	public static final DeferredHolder<SoundEvent, SoundEvent> NIGHTSTAY = REGISTRY.register("nightstay", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stratospherion", "nightstay")));
}