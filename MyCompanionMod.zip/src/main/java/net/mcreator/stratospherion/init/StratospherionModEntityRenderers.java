/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stratospherion.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.stratospherion.client.renderer.EveRenderer;

@EventBusSubscriber(Dist.CLIENT)
public class StratospherionModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(StratospherionModEntities.EVE.get(), EveRenderer::new);
		event.registerEntityRenderer(StratospherionModEntities.BEAM.get(), ThrownItemRenderer::new);
	}
}