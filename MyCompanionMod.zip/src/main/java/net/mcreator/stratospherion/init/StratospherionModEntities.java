/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stratospherion.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.registries.Registries;

import net.mcreator.stratospherion.entity.EveEntity;
import net.mcreator.stratospherion.entity.BeamEntity;
import net.mcreator.stratospherion.StratospherionMod;

@EventBusSubscriber
public class StratospherionModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, StratospherionMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<EveEntity>> EVE = register("eve", EntityType.Builder.<EveEntity>of(EveEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

			.sized(1f, 0.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<BeamEntity>> BEAM = register("beam",
			EntityType.Builder.<BeamEntity>of(BeamEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(RegisterSpawnPlacementsEvent event) {
		EveEntity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(EVE.get(), EveEntity.createAttributes().build());
	}
}