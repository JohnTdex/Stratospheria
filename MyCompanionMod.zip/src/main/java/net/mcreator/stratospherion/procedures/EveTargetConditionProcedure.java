package net.mcreator.stratospherion.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.stratospherion.entity.EveEntity;

public class EveTargetConditionProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		Entity eve = null;
		if (entity instanceof EveEntity) {
			return false;
		}
		return true;
	}
}