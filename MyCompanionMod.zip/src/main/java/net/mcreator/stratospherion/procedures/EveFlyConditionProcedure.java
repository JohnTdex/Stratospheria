package net.mcreator.stratospherion.procedures;

import net.minecraft.world.entity.Entity;

public class EveFlyConditionProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		return !entity.getPersistentData().getBoolean("eve_stay_mode");
	}
}