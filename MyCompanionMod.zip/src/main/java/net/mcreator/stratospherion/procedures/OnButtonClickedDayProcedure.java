package net.mcreator.stratospherion.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

import net.mcreator.stratospherion.entity.EveEntity;
import net.mcreator.stratospherion.StratospherionMod;

import java.util.Comparator;

public class OnButtonClickedDayProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		Entity TargetEve = null;
		if (world.dayTime() >= 0 && world.dayTime() <= 5999) {
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(
						Component.literal(((findEntityInWorldRange(world, EveEntity.class, x, y, z, 20)).getDisplayName().getString() + "" + (": Good Morning " + (entity.getDisplayName().getString() + ". Ready for your mission?")))), false);
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:goodmorning")), SoundSource.NEUTRAL, 1, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:goodmorning")), SoundSource.NEUTRAL, 1, 1, false);
				}
			}
			StratospherionMod.queueServerWork(80, () -> {
				if (world.getLevelData().isRaining() || world.getLevelData().isThundering()) {
					if (entity instanceof Player _player && !_player.level().isClientSide())
						_player.displayClientMessage(
								Component.literal(((findEntityInWorldRange(world, EveEntity.class, x, y, z, 20)).getDisplayName().getString() + ": Hmm, It appears the atmosphere has decided to submerge our... entire region in a trial by water.")),
								false);
					if (world instanceof Level _level) {
						if (!_level.isClientSide()) {
							_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:ohnorain")), SoundSource.NEUTRAL, 1, 1);
						} else {
							_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:ohnorain")), SoundSource.NEUTRAL, 1, 1, false);
						}
					}
				}
			});
		} else {
			if (world.dayTime() >= 6000 && world.dayTime() <= 12999) {
				if (entity instanceof Player _player && !_player.level().isClientSide())
					_player.displayClientMessage(Component.literal(((findEntityInWorldRange(world, EveEntity.class, x, y, z, 20)).getDisplayName().getString() + ""
							+ (": Greetings " + (entity.getDisplayName().getString() + ". For correction, it is Noon. I supposed you lost track of time?")))), false);
				if (world instanceof Level _level) {
					if (!_level.isClientSide()) {
						_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:nooncorrection")), SoundSource.NEUTRAL, 1, 1);
					} else {
						_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:nooncorrection")), SoundSource.NEUTRAL, 1, 1, false);
					}
				}
			} else {
				if (world.dayTime() >= 13000 && world.dayTime() <= 23999) {
					if (entity instanceof Player _player && !_player.level().isClientSide())
						_player.displayClientMessage(Component.literal(((findEntityInWorldRange(world, EveEntity.class, x, y, z, 20)).getDisplayName().getString() + ""
								+ (": Greetings " + (entity.getDisplayName().getString() + ". For correction, it is Night. I supposed you lost track of time?")))), false);
					if (world instanceof Level _level) {
						if (!_level.isClientSide()) {
							_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:nightcorrection")), SoundSource.NEUTRAL, 1, 1);
						} else {
							_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:nightcorrection")), SoundSource.NEUTRAL, 1, 1, false);
						}
					}
				}
			}
		}
		if (entity instanceof Player _player)
			_player.closeContainer();
	}

	private static Entity findEntityInWorldRange(LevelAccessor world, Class<? extends Entity> clazz, double x, double y, double z, double range) {
		return (Entity) world.getEntitiesOfClass(clazz, AABB.ofSize(new Vec3(x, y, z), range, range, range), e -> true).stream().sorted(Comparator.comparingDouble(e -> e.distanceToSqr(x, y, z))).findFirst().orElse(null);
	}
}