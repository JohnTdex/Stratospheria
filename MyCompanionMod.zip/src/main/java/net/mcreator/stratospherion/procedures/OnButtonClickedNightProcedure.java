package net.mcreator.stratospherion.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.stratospherion.network.StratospherionModVariables;
import net.mcreator.stratospherion.entity.EveEntity;
import net.mcreator.stratospherion.StratospherionMod;

import java.util.Comparator;

public class OnButtonClickedNightProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		Entity foundeve = null;
		foundeve = findEntityInWorldRange(world, EveEntity.class, x, y, z, 20);
		if (!world.getEntitiesOfClass(EveEntity.class, new AABB(Vec3.ZERO, Vec3.ZERO).move(new Vec3(x, y, z)).inflate(10 / 2d), e -> true).isEmpty()) {
			if (world.dayTime() >= 13000 && world.dayTime() <= 23999) {
				if (entity instanceof Player _player && !_player.level().isClientSide())
					_player.displayClientMessage(Component.literal((foundeve.getDisplayName().getString() + "" + (": Good Evening " + (entity.getDisplayName().getString()
							+ ". I am initiating safety protocols. Please be aware that nighttime operations carry significant risks; current data indicates that hostile entities are predominantly active after sunset. I urge you to maintain optimal situational awareness.")))),
							false);
				if (world instanceof Level _level) {
					if (!_level.isClientSide()) {
						_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:evening")), SoundSource.NEUTRAL, 1, 1);
					} else {
						_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:evening")), SoundSource.NEUTRAL, 1, 1, false);
					}
				}
				StratospherionMod.queueServerWork(400, () -> {
					if (world.getLevelData().isRaining() || world.getLevelData().isThundering()) {
						if (entity instanceof Player _player && !_player.level().isClientSide())
							_player.displayClientMessage(Component.literal(((findEntityInWorldRange(world, EveEntity.class, x, y, z, 50)).getDisplayName().getString() + ""
									+ (": The night reeks of rainwater. " + (entity.getDisplayName().getString() + " , Further expeditions escalate the risk of life-threatening scenarios.")))), false);
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:nightrain")), SoundSource.NEUTRAL, 1, 1);
							} else {
								_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:nightrain")), SoundSource.NEUTRAL, 1, 1, false);
							}
						}
						StratospherionModVariables.WorldVariables.get(world).dialogue_state = 1;
						StratospherionModVariables.WorldVariables.get(world).markSyncDirty();
						if (world instanceof ServerLevel _level)
							_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
									"tellraw @p {\"text\":\": Do you wish to proceed? \",\"color\":\"aqua\",\"extra\":[{\"text\":\"[YES] \",\"color\":\"green\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/yes_eve\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"Click to proceed\"}}},{\"text\":\"[NO]\",\"color\":\"red\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/no_eve\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"Click to stay safe inside\"}}}]}");
					}
				});
			} else {
				if (world.dayTime() >= 0 && world.dayTime() <= 5999) {
					if (entity instanceof Player _player && !_player.level().isClientSide())
						_player.displayClientMessage(Component.literal((foundeve.getDisplayName().getString() + "" + (": Greetings " + (entity.getDisplayName().getString() + ". For correction, it is Morning. I supposed you lost track of time?")))),
								false);
					if (world instanceof Level _level) {
						if (!_level.isClientSide()) {
							_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:morningcorrection")), SoundSource.NEUTRAL, 1, 1);
						} else {
							_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:morningcorrection")), SoundSource.NEUTRAL, 1, 1, false);
						}
					}
				} else {
					if (world.dayTime() >= 6000 && world.dayTime() <= 12999) {
						if (entity instanceof Player _player && !_player.level().isClientSide())
							_player.displayClientMessage(Component.literal((foundeve.getDisplayName().getString() + "" + (": Greetings " + (entity.getDisplayName().getString() + ". For correction, it is Noon. I supposed you lost track of time?")))),
									false);
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:nooncorrection")), SoundSource.NEUTRAL, 1, 1);
							} else {
								_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:nooncorrection")), SoundSource.NEUTRAL, 1, 1, false);
							}
						}
					}
				}
			}
			if (entity instanceof Player _player)
				_player.closeContainer();
		}
	}

	private static Entity findEntityInWorldRange(LevelAccessor world, Class<? extends Entity> clazz, double x, double y, double z, double range) {
		return (Entity) world.getEntitiesOfClass(clazz, AABB.ofSize(new Vec3(x, y, z), range, range, range), e -> true).stream().sorted(Comparator.comparingDouble(e -> e.distanceToSqr(x, y, z))).findFirst().orElse(null);
	}
}