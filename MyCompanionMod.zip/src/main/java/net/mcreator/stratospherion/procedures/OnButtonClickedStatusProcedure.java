package net.mcreator.stratospherion.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

import net.mcreator.stratospherion.entity.EveEntity;
import net.mcreator.stratospherion.StratospherionMod;

import java.util.Comparator;

public class OnButtonClickedStatusProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (((findEntityInWorldRange(world, EveEntity.class, x, y, z, 4)) instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) < 20) {
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:analyzing_complete")), SoundSource.NEUTRAL, 1, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:analyzing_complete")), SoundSource.NEUTRAL, 1, 1, false);
				}
			}
			if ((findEntityInWorldRange(world, Player.class, x, y, z, 4)) instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal(((findEntityInWorldRange(world, EveEntity.class, x, y, z, 4)).getDisplayName().getString() + " : System status is... Critical. Repair is required.")), false);
			if ((findEntityInWorldRange(world, Player.class, x, y, z, 20)) instanceof Player _player)
				_player.closeContainer();
			StratospherionMod.queueServerWork(50, () -> {
				if (world instanceof Level _level) {
					if (!_level.isClientSide()) {
						_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:low_health")), SoundSource.NEUTRAL, 1, 1);
					} else {
						_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:low_health")), SoundSource.NEUTRAL, 1, 1, false);
					}
				}
			});
		} else {
			if (((findEntityInWorldRange(world, EveEntity.class, x, y, z, 4)) instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) > 20) {
				if (world instanceof Level _level) {
					if (!_level.isClientSide()) {
						_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:analyzing_complete")), SoundSource.NEUTRAL, 1, 1);
					} else {
						_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:analyzing_complete")), SoundSource.NEUTRAL, 1, 1, false);
					}
				}
				if ((findEntityInWorldRange(world, Player.class, x, y, z, 4)) instanceof Player _player && !_player.level().isClientSide())
					_player.displayClientMessage(Component.literal(((findEntityInWorldRange(world, EveEntity.class, x, y, z, 4)).getDisplayName().getString() + " : System status is... Stable! What do you want to do today?")), false);
				if ((findEntityInWorldRange(world, Player.class, x, y, z, 20)) instanceof Player _player)
					_player.closeContainer();
				StratospherionMod.queueServerWork(50, () -> {
					if (world instanceof Level _level) {
						if (!_level.isClientSide()) {
							_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:full_health")), SoundSource.NEUTRAL, 1, 1);
						} else {
							_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:full_health")), SoundSource.NEUTRAL, 1, 1, false);
						}
					}
				});
			}
		}
	}

	private static Entity findEntityInWorldRange(LevelAccessor world, Class<? extends Entity> clazz, double x, double y, double z, double range) {
		return (Entity) world.getEntitiesOfClass(clazz, AABB.ofSize(new Vec3(x, y, z), range, range, range), e -> true).stream().sorted(Comparator.comparingDouble(e -> e.distanceToSqr(x, y, z))).findFirst().orElse(null);
	}
}