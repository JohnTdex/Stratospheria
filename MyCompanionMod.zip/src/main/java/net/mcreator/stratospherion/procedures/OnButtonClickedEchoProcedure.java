package net.mcreator.stratospherion.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.Slime;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

import net.mcreator.stratospherion.network.StratospherionModVariables;
import net.mcreator.stratospherion.entity.EveEntity;
import net.mcreator.stratospherion.StratospherionMod;

import java.util.Comparator;

public class OnButtonClickedEchoProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		boolean hostile_found = false;
		Entity target_eve = null;
		StratospherionModVariables.target_eve = findEntityInWorldRange(world, EveEntity.class, x, y, z, 20);
		hostile_found = false;
		{
			final Vec3 _center = new Vec3(x, y, z);
			for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(50 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList()) {
				if (entityiterator instanceof Monster || entityiterator instanceof Slime) {
					if (entityiterator instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.GLOWING, 200, 1, false, false));
					hostile_found = true;
				}
			}
		}
		if (hostile_found == true) {
			if (StratospherionModVariables.target_eve instanceof EveEntity) {
				if (world instanceof Level _level) {
					if (!_level.isClientSide()) {
						_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:echo")), SoundSource.NEUTRAL, 1, 1);
					} else {
						_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:echo")), SoundSource.NEUTRAL, 1, 1, false);
					}
				}
				StratospherionMod.queueServerWork(120, () -> {
					if (StratospherionModVariables.target_eve instanceof EveEntity) {
						if (entity instanceof Player _player && !_player.level().isClientSide())
							_player.displayClientMessage(Component.literal((StratospherionModVariables.target_eve.getDisplayName().getString() + ": Hostile Scanning Complete.")), false);
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:scan")), SoundSource.NEUTRAL, 1, 1);
							} else {
								_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:scan")), SoundSource.NEUTRAL, 1, 1, false);
							}
						}
						StratospherionMod.queueServerWork(30, () -> {
							if (entity instanceof Player _player && !_player.level().isClientSide())
								_player.displayClientMessage(Component.literal((StratospherionModVariables.target_eve.getDisplayName().getString() + ": Please proceed with caution.")), false);
							if (world instanceof Level _level) {
								if (!_level.isClientSide()) {
									_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:danger")), SoundSource.NEUTRAL, 1, 1);
								} else {
									_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:danger")), SoundSource.NEUTRAL, 1, 1, false);
								}
							}
						});
					}
				});
			}
		} else {
			if (StratospherionModVariables.target_eve instanceof EveEntity) {
				if (world instanceof Level _level) {
					if (!_level.isClientSide()) {
						_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:echo")), SoundSource.NEUTRAL, 1, 1);
					} else {
						_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:echo")), SoundSource.NEUTRAL, 1, 1, false);
					}
				}
				StratospherionMod.queueServerWork(120, () -> {
					if (StratospherionModVariables.target_eve instanceof EveEntity) {
						if (entity instanceof Player _player && !_player.level().isClientSide())
							_player.displayClientMessage(Component.literal((StratospherionModVariables.target_eve.getDisplayName().getString() + ": Hostile Scanning Complete.")), false);
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:scan")), SoundSource.NEUTRAL, 1, 1);
							} else {
								_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:scan")), SoundSource.NEUTRAL, 1, 1, false);
							}
						}
						StratospherionMod.queueServerWork(30, () -> {
							if (entity instanceof Player _player && !_player.level().isClientSide())
								_player.displayClientMessage(Component.literal((StratospherionModVariables.target_eve.getDisplayName().getString() + ": Surroundings Secured.")), false);
							if (world instanceof Level _level) {
								if (!_level.isClientSide()) {
									_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:safe")), SoundSource.NEUTRAL, 1, 1);
								} else {
									_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("stratospherion:safe")), SoundSource.NEUTRAL, 1, 1, false);
								}
							}
						});
					}
				});
			}
		}
		if (entity instanceof Player _player)
			_player.closeContainer();
	}

	private static Entity findEntityInWorldRange(LevelAccessor world, Class<? extends Entity> clazz, double x, double y, double z, double range) {
		return (Entity) world.getEntitiesOfClass(clazz, AABB.ofSize(new Vec3(x, y, z), range, range, range), e -> true).stream().sorted(Comparator.comparingDouble(e -> e.distanceToSqr(x, y, z))).findFirst().orElse(null);
	}
}